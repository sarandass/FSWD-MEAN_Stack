import React, { Component } from 'react'
import ReactDOM from 'react-dom'

// ReactDOM.render(<h1>Welcome To Your Life</h1>, document.getElementById('life'))
// let element = <div>
//                 <h1>Welcome To Your Life</h1>
//                 <ul>
//                     <li>Home</li>
//                     <li>About</li>
//                     <li>Softwares</li>
//                     <li>Help</li>
//                 </ul>
//               </div>

// ReactDOM.render(element, document.getElementById('life'))

// let element = React.createElement("h1", {title:"Heading"}, "Welcome To Your Life !!!")
// ReactDOM.render(element, document.getElementById('life'))

// let element = React.createElement('ol', null,
// React.createElement('li', null, "Home"),
// React.createElement('li', null, "About"),
// React.createElement('li', null, "Softwares"),
// React.createElement('li', null, "Help"),
// )

// ReactDOM.render(element, document.getElementById('life'))

// Element
// let element = <div>
//                 <h1>Welcome To My First React APP</h1>
//                 <ol>
//                     <li>Home</li>
//                     <li>About</li>
//                     <li>Softwares</li>
//                     <li>Help</li>
//                 </ol>
//                 <ul>
//                     <li>Home</li>
//                     <li>About</li>
//                     <li>Softwares</li>
//                     <li>Help</li>
//                 </ul>
//               </div>

// Component
function Item() {
    return <li>Loop</li>
}

// function Firstcomp() {
//     return <div>
//             <h1>Welcome To My First React APP</h1>
//             <ol>
//                 <Item/>
//                 <Item/>
//                 <Item/>
//                 <Item/>
//             </ol>
//             <ul>
//                 <li>Home</li>
//                 <li>About</li>
//                 <li>Softwares</li>
//                 <li>Help</li>
//             </ul>
//         </div>
// }

class Firstcomp extends Component {
     render() {
            return <div>
                    <h1>Welcome To My First React APP</h1>
                    <ol>
                        <Item/>
                        <Item/>
                        <Item/>
                        <Item/>
                    </ol>
                    <ul>
                        <li>Home</li>
                        <li>About</li>
                        <li>Softwares</li>
                        <li>Help</li>
                    </ul>
                </div>
     }
}
ReactDOM.render(<Firstcomp/>, document.getElementById('life'))              